import TaskContent from '@/components/tasks/TaskContent'
import React from 'react'

const page = () => {
  return (
    <>
      <TaskContent />
    </>
  )
}

export default page