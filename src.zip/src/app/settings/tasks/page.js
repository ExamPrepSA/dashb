import SettingsTasksForm from '@/components/setting/settingsTasksForm'
import React from 'react'

const page = () => {
    return (
        <>
            <SettingsTasksForm />
        </>
    )
}

export default page