import SettingsLocalizationForm from '@/components/setting/settingsLocalizationForm'
import React from 'react'

const page = () => {
    return (
        <><SettingsLocalizationForm /></>
    )
}

export default page